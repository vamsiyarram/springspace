package pl.piomin.service.common.message;

public enum ShipmentType {

	CAR, PLANE, SHIP, TRAIN;
	
}
