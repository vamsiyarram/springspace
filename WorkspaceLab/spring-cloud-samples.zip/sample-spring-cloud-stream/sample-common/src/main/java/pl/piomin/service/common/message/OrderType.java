package pl.piomin.service.common.message;

public enum OrderType {

	PURCHASE, RETURN, EXCHANGE;
}
